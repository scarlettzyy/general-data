﻿'''
extract_vina_score.py [input dir] [output file] (optional)
'''
import os   #导入os模块
import sys  #导入sys模块


if len(sys.argv) < 2: #如果用户输入的变量长度少于2个
    print(__doc__) #打印输出首行
    sys.exit(0) #退出程序
dout = sys.argv[1]  # 定义dout变量，将输入的命令中index为1的命令赋值给dout，例如输入python.exe .\extract_vina_score.py .\ligand1,则dout==.\ligand1
fout = 'vina_scores.txt' #定义fout变量，将vina_scores.txt字符串赋值给fout，这个文件将作为打分默认输出文件名
if len(sys.argv) >= 3: #如果用户输入的变量长度大于等于3个
    fout = sys.argv[2] #将用户输入的命令中index为2的字符串复制给fout，例如输入python.exe .\extract_vina_score.py .\ligand1 scores.txt，则将scores.txt赋值给fout
files = os.listdir(dout) #定义files变量，将dout文件夹中的文件作为列表赋值给files，切记files是一个列表，包含有dout文件夹中的所有文件。
scores = [] #定义一个空列表赋值给scores
for f in files: # 循环files列表中的每一个文件，每一次循环都将文件名赋值给f
    if f.endswith('_out.pdbqt') or f.endswith('_out.PDBQT'): #如果文件以_out.pdbqt或者_out.PDBQT结尾
        name = os.path.splitext(f)[0][:-4] #splitext函数用来分离文件的文件名，扩展名。[0] 表示提取文件名，[:-4]表示只需要文件名的开头到倒数第四个字符，也就是不包括_out。将提取的字符串赋值给name变量
        for line in open(os.path.join(dout,f)): #os.path.join(dout,f) 表示将dout和f一起拼接为路径，
												#如dout==ligand1 f==ligand2_out.pdbqt,则os.path.join(dout,f)==ligand1\ligand2_out.pdbqt。
												#open表示打开读取文件，默认会将文件中的所有行放到一个列表中，这里把每一行都赋值给line
            if line.startswith('REMARK VINA RESULT:'): #如果line以REMARK VINA RESULT:开头，
                scores.append([name,line.split()[3]])  #拼接scores列表。line.split()[3]表示以空格分隔字符串之后取index为3的字符串，
													   #如REMARK VINA RESULT:      -6.7      0.000      0.000这一行，line.split()[3]==-6.7
													   #如name==ligand1,则[name,line.split()[3]==[ligand1,-6.7]
                #break   #终止该if所在的for循环，也就是说终止内层for循环，继续到下一次外层for循环。
f = open(fout,'wb') #打开fout文件以'wb'二进制的方式写入。
f.write('Name\tAffinity (kcal/mol)\n') #写入Name 表格键 Affinity (kcal/mol) 换行 ，例如：Name	Affinity (kcal/mol)
for i,j in scores: # 这里i代表key（键），j代表value（值），循环的是scores列表。对于scores中的某一项如[ligand1,-6.7]，则i==ligand1,j==-6.7
    f.write('%s\t%s\n' % (i,j)) #定义写出格式，以'i表格键j换行'的方式写出
f.close() #关闭文件
print('Extraction complete. Vina scores are stored in %s.'% fout) #打印输出提取完成提示，并告诉用户打分存储在fout文件里。
    
